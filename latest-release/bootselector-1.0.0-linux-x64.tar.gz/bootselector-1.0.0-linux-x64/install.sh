#!/bin/bash
set -e
INSTALL_DIR="/opt/bootselector"
echo "Installing Boot Selector to $INSTALL_DIR..."
sudo mkdir -p "$INSTALL_DIR"
sudo cp -r ./* "$INSTALL_DIR/"
sudo chmod +x "$INSTALL_DIR/bootselector"
sudo ln -sf "$INSTALL_DIR/bootselector" /usr/local/bin/bootselector

# Desktop entry
sudo mkdir -p /usr/share/applications
sudo tee /usr/share/applications/bootselector.desktop > /dev/null << 'DESKTOP'
[Desktop Entry]
Name=Boot Selector
Comment=Select which OS to boot on next restart
Exec=/opt/bootselector/bootselector
Icon=/opt/bootselector/icon.png
Terminal=false
Type=Application
Categories=System;Settings;
DESKTOP

echo "✅ Installation complete! Run 'bootselector' or find it in your applications menu."
